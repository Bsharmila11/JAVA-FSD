package com;

public class Product {
 public void productInfo()
 {
	 System.out.println("Product Info Method");
 }
}

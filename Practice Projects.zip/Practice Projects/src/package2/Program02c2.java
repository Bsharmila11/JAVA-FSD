package package2;
import package1.*;
public class Program02c2 extends Program02c1 
{
	public static void main(String[] args) 
	{
		Program02c2 obj = new Program02c2 ();   
	       obj.display();  
	}

}

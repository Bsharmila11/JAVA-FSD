package package2;
import package1.*;
public class Program02d2 
{
	public static void main(String[] args) 
	{
		Program02d1 obj = new Program02d1(); 
        obj.display();  
		}
}


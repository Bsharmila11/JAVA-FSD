package package1;
public class Program02c1{

	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}

